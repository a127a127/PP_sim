# non-pipeline
python3 PP_sim.py 0 0
python3 PP_sim.py 0 1
python3 PP_sim.py 1 0
python3 PP_sim.py 1 1
python3 PP_sim.py 2 0
python3 PP_sim.py 2 1
